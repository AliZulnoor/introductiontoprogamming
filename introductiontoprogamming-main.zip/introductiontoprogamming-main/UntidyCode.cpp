#include <iostream>
#include <string>
using namespace std;

int main() 
{
    int number = 7;

    cout << "This is untidy code."<<endl;

    cout << "How does work ? No one knows" << endl;

    cout << "It has " << number << " lines of code" << endl;

    cout << "None of them make any sense." << endl;

    cout << "What is the smell of the sky" << endl;

    return 0;
}