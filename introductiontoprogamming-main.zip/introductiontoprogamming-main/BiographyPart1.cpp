#include<iostream>
using namespace std;
int main()
{
	string name = "Ali"; // Using string as datatype
	
	int age = 18; // Using integer as Data type

	string hometown = "lahore"; // Using String as Data type

	cout << "Name: " << name << endl << "Age:  " << age << endl << "Hometown: " << hometown << endl; // Printing all information using cout once

	return 0;
}
