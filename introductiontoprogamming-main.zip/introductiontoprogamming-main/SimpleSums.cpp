#include<iostream>
using namespace std;
int main()
{
	int a = 8; // Initializing a = 8

	int b = 10; // Initializing b = 10

	int sum = a + b; // Initializing sum to be equal to a+b

	cout << "Sum = " << sum << endl; // Answer

	return 0;
}
