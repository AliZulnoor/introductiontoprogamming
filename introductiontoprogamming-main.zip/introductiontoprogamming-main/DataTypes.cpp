#include <iostream>
#include <string>
using namespace std;

int main()
{
    int firstNumber = 1;

    cout << "firstNumber = " << firstNumber << endl;

    bool iCanCode = true;

    cout << "iCanCode = " << iCanCode << endl;

    char hopefulGrade = 'a';

    cout << "hopefulGrade = " << hopefulGrade << endl;

    float myDecimal = 1.0;

    cout << "myDecimal = " << myDecimal << endl;

    string minimalSentance = "y";

    cout << "minimalSentance = " << minimalSentance << endl;

    long keyMash = 13213123;

    cout << "keyMash = " << keyMash << endl;

    float mysteryDataType = 5.6; //Use Google to work this out

    cout << "mysteryDataType = " << mysteryDataType << endl;

    return 0;
}