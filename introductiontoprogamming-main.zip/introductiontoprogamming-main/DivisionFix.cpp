#include <iostream>
using namespace std;

int main()
{
    float numberOne = 50; //  changing the data types from integer to floating point to get the values in decimal

    float numberTwo = 7;

    cout << numberOne / numberTwo << endl;

    return 0;
}